struct bucket {
	unsigned char *data;
	uint32_t flags;
};

