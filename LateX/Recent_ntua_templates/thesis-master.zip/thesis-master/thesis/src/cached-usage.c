-mo       | Number of ops | Max objects to cache\n"
-ts       | None          | Total cache size\n"
-os       | 4MiB          | Object size\n"
-bs       | 4KiB          | Bucket size\n"
-mrs      | 512KiB        | Max request size\n"
-bp       | None          | Blocker port\n"
-wcp      | writethrough  | Write policy [writethrough|writeback]\n"

