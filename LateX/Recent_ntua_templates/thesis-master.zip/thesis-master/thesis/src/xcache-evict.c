xcache_handler xcache_evict_lru(struct xcache *cache);
xcache_handler xcache_peek_and_get_lru(struct xcache *cache);

