xcache_handler xcache_alloc_init(struct xcache *cache, char *name);
