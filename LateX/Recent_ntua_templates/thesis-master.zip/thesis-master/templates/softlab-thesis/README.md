softlab-thesis
==============
* [About](#about)
* [How-to](#how-to)

# About #
This is an unofficial template for softlab theses. All rights go to the
respective owners.

# How-to #

Provided you have installed LaTeX as well as the `latexmk` tool, you can do:

```
make
```

and a `thesis.pdf` file will be created.

If you want to remove the helper files, you can do

```
make clean
```

while if you want to clean all produced files (the .pdf file too) you can do:

```
make distclean
```



