foo [] = []
foo h:t = 9: foo t
