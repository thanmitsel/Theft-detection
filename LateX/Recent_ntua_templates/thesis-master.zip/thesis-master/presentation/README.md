# Beamer theme for Atilla

## Authors

Based on Torino theme by Marco Barisione.
Modified in 2011 by Dan Forest-Barbier and Pierre Sudron.

## Licence

This file may be distributed and/or modified :
 * under the LaTeX Project Public License and/or
 * under the GNU Public License

## Usage

Copy the beamertheme_atilla folder into your work repository.
Then in you main LaTeX file, add the following line in your headers :

`\usepackage{beamertheme_atilla/beamerthemeAtilla}`

This beamer theme is known to work well with pdflatex.
